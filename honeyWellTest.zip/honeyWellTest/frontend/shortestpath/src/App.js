import logo from './logo.svg';
import './App.css';
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ReactMapGL, { Marker, Popup } from 'react-map-gl';
import { StaticMap } from "react-map-gl";

const MAPBOX_ACCESS_TOKEN =
  "pk.eyJ1IjoiZ2Vvcmdpb3MtdWJlciIsImEiOiJjanZidTZzczAwajMxNGVwOGZrd2E5NG90In0.gdsRu_UeU_uPi9IulBruXA";
function App() {
  const [cities, setCities] = useState([]);
  const [selectedCity, setSelectedCity] = useState(null);
  const [selectedcityOne, setSelectedcityOne] = useState('');
  const [selectedCityTwo, setSelectedCityTwo] = useState('');
  const [viewport, setViewport] = useState({
    width: '100%',
    height: '400px',
    latitude: 37.7749,
    longitude: -122.4194,
    zoom: 10,
  });

  useEffect(() => {
    getAllCities();
  },[]);

  const getAllCities = async() => {
    await axios.get('http://localhost:8080/allCities')
    .then((res) => {
      const result = res.data;
      setCities(result);
    }).catch((e) => {
      console.log(e)
    })
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    calculateShortestPath(selectedcityOne,selectedCityTwo);
  };

  const handleCitySelect = (city) => {
    setSelectedCity(city);
    // Trigger backend logic for shortest path
    calculateShortestPath(selectedCity, city);
  };

  const calculateShortestPath = async (startCity, endCity) => {
    try {
      const response = await fetch('http://localhost:8080/shortestPath', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ origin:startCity, destination: endCity }),
      });
  
      const data = await response.json();
      console.log('Shortest Path:', data.shortestPath);
      // Update the UI or map with the shortest path information
    } catch (error) {
      console.error('Error calculating shortest path:', error);
    }
  };

  return (
    <>
    <div className="App">
       <div className="form-container row">
      <div className='col-6'>
      <label className="form-label">
        Dropdown 1:
        <select
          className="form-select"
          value={selectedcityOne}
          onChange={(e) => setSelectedcityOne(e.target.value)}
        >
           { cities.map((option) => {
              return (
                <option value={option.id}>{option.value}</option>
              )
            })
          }
        </select>
      </label>
      </div>
      <br />
      <div className='col-6'>
      <label className="form-label">
        Dropdown 2:
        <select
          className="form-select"
          value={selectedCityTwo}
          onChange={(e) => setSelectedCityTwo(e.target.value)}
        >
         {cities.map((option) => {
              return (
                <option value={option.id}>{option.value}</option>
              )
            })
          }
        </select>
      </label>
    </div>
      <br />

      <button className="form-button" onClick={handleSubmit}>
        Submit
      </button>
    </div>
    </div>
   
{/* 
<div>
<h1>City Map</h1>
<ReactMapGL
      {...viewport}
      mapboxApiAccessToken={MAPBOX_ACCESS_TOKEN} 
      onViewportChange={(newViewport) => setViewport(newViewport)}
    >
      {cities.map((city) => (
        <Marker
          key={city.id}
          latitude={city.lat}
          longitude={city.lon}
        >
          <button
            className="marker-btn"
            onClick={() => handleCitySelect(city)}
          >
            🏙️
          </button>
        </Marker>
      ))}

      {selectedCity && (
        <Popup
          latitude={selectedCity.lat}
          longitude={selectedCity.lon}
          onClose={() => handleCitySelect(null)}
        >
          <div>
            <h2>{selectedCity.name}</h2>
          </div>
        </Popup>
      )}
    </ReactMapGL>
</div> */}
</>
  );
}

export default App;
