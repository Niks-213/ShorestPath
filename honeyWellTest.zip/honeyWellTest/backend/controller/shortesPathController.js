const fs = require('fs');
const path = require('path');
const citiesFilePath = path.join(__dirname, '..', 'data', 'sampleData.json');
const { Client } = require('@googlemaps/google-maps-services-js');

const getHelloWorld = (req, res) => {
    res.send('Hello, World!');
  };

  const gatAllData = (req, res) => {
    fs.readFile(citiesFilePath, 'utf8', (err, data) => {
      if (err) {
        console.error('Error reading sampleData.json:', err);
        res.status(500).send('Internal Server Error');
        return;
      }
  
      const result = JSON.parse(data);
      res.json(result);
    });
  };

  const getAllCities = (req, res) => {
    fs.readFile(citiesFilePath, 'utf8', (err, data) => {
      if (err) {
        console.error('Error reading sampleData.json:', err);
        res.status(500).send('Internal Server Error');
        return;
      }
  
      
      const result = JSON.parse(data);
      const cities = result.map((item) => {
        return {
            id: item.name,
            value: item.name
        }
      })
      res.json(cities);
    });
  };

  const getShortesPath = async(req, res) => {
    const googleMapsClient = new Client({});
    console.log("===res:",req)
    const origin = req.body.origin;
    try {
        const response = await googleMapsClient.directions({
          params: {
            origin: `${origin.lat},${origin.lon}`,
            destination: `${destination.lat},${destination.lon}`,
            key: 'YOUR_GOOGLE_MAPS_API_KEY',
          },
        });
    
        const legs = response.data.routes[0].legs;
        const shortestPath = legs.map((leg) => leg.start_address);
    
        res.json({ shortestPath });
      } catch (error) {
        console.error('Error calculating shortest path:', error);
        res.status(500).json({ error: 'Internal Server Error' });
      }
  };
  
  
  module.exports = {
    getHelloWorld,
    gatAllData,
    getAllCities,
    getShortesPath
  };