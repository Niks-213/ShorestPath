const express = require('express');
const router = express.Router();
const shortestPathController = require('../controller/shortesPathController');

router.get('/hello', shortestPathController.getHelloWorld);
router.get('/allData', shortestPathController.gatAllData);
router.get('/allCities', shortestPathController.getAllCities);
router.post('/shortestPath', shortestPathController.getShortesPath);

module.exports = router;